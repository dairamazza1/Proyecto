import { createClient } from "@supabase/supabase-js";   

// export const supabase = createClient(
//    'https://rgdwhubxfihlygtfvabw.supabase.co',
// 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJnZHdodWJ4ZmlobHlndGZ2YWJ3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUwNzA4NjUsImV4cCI6MjA4MDY0Njg2NX0.-2ZwrKGW93hikiG1lHlSRyZZCGl5uzpuAVVXGd_65PM');



export const supabase = createClient(
    import.meta.env.VITE_APP_SUPABASE_URL,
    import.meta.env.VITE_APP_SUPABASE_ANON_KEY
); 