import styled from "styled-components";
export const Icono = styled.span`
   display:flex;
   align-items:center;
   text-align:center;
    font-size:20px;
    color:${(props)=>props.$color};
  
  
`