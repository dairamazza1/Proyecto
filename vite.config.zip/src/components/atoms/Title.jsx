import styled from "styled-components";
export const Title = styled.span`
    font-size: 30px;   
    font-weight: 700;
    padding-bottom: ${(props) => props.$paddingbottom };
`;