//acá se muestran datos. El template es el que tiene la estructura de la página

import { LoginTemplate } from "../index";

export function Login() {
    return (<LoginTemplate/>);
}
