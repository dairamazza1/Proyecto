//acá se muestran datos. El template es el que tiene la estructura de la página

import { HomeTemplate } from "../index";

export function Home() {
    return (<HomeTemplate/>);
}
